<?php namespace App\Controllers;

use App\Models\UsuarioModel;


class Usuario extends BaseController
{
	public function index()
	{
		$data = [];
		helper(['form']);

		echo view('templates/header', $data);
		echo view('RegistroSatisfactorio');
		echo view('templates/footer');
	}

	public function registro(){
		$data = [];
		helper(['form']);

		if ($this->request->getMethod() == 'post') {
			$rules = [
				'nombre' => 'required|min_length[3]|max_length[20]',
				'apellidos' => 'required|min_length[3]|max_length[20]',
				'email' => 'required|min_length[6]|max_length[50]|valid_email|is_unique[usuario.email]',
				'password' => 'required|min_length[8]|max_length[255]',
				'password_confirm' => 'matches[password]',
			];

			if (! $this->validate($rules)) {
				$data['validation'] = $this->validator;
			}else{
				$model = new UsuarioModel();

				$newData = [
					'nombre' => $this->request->getVar('nombre'),
					'apellidos' => $this->request->getVar('apellidos'),
					'email' => $this->request->getVar('email'),
					'password' => $this->request->getVar('password'),
				];
				$model->save($newData);
				$session = session();
				$session->setFlashdata('success', 'Successful Registration');
				return redirect()->to('/');

			}
		}


		echo view('templates/header', $data);
		echo view('registro');
		echo view('templates/footer');
	}

}